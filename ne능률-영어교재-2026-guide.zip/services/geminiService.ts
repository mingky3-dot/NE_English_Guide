
import { GoogleGenAI } from "@google/genai";
import { Page } from "../types";

export class GeminiService {
  private getClient() {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.warn("GEMINI_API_KEY is missing. AI features will not work.");
    }
    return new GoogleGenAI({ apiKey: apiKey || "" });
  }

  async recommendBook(userQuery: string, currentPages: Page[]): Promise<{ text: string; sources?: any[] }> {
    const ai = this.getClient();
    
    const contextInfo = currentPages.filter(p => p.type === 'body')
      .map(p => {
        const d = p.details;
        return `[교재명: ${p.title}] 
- 대상: ${d?.target} 
- 영역: ${d?.nelt}
- 주요특징: ${d?.features.join(', ')}
- 전문가 추천: ${d?.recommendation}
- 시리즈구성: ${d?.subBooks?.map(b => b.title).join(', ')}
- 제공자료: ${d?.resources?.map(r => r.label).join(', ')}`;
      })
      .join('\n\n');

    const systemPrompt = `당신은 'NE능률'의 공식 AI 수석 상담원입니다. 
당신이 알고 있는 정보는 아래의 [실시간 교재 데이터]에 국한됩니다.

[실시간 교재 데이터]
${contextInfo}

[상담 미션]
1. 사용자의 상황에 가장 적합한 교재를 위 데이터에서 찾으세요.
2. **간결하고 핵심만 노출되는 형태**로 답변하세요. 불필요한 서술은 지양하고 핵심 정보 위주로 작성하세요.
3. 답변 구성:
   - ### [학습 진단]
     사용자의 현재 상황 한 줄 요약
   - ### [추천 교재]
     추천 교재명과 선정이유 (핵심 특징 2-3개)
   - ### [학습 팁]
     해당 교재 활용법 한 줄
4. 추천하는 교재명은 반드시 \`[교재명]\` 형식으로 작성하세요. (예: [능률 VOCA 어원편])
5. 구글 검색을 활용해 최신 교육 트렌드와 연계하되, 답변은 짧고 명확하게 유지하세요.

한국어로 답변하고 중요 포인트는 **볼드체**로 표시하세요. ### 헤더를 사용하여 섹션을 구분하세요.`;

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.1-pro-preview',
        contents: userQuery,
        config: {
          systemInstruction: systemPrompt,
          tools: [{ googleSearch: {} }],
          temperature: 0.7,
        }
      });
      
      return {
        text: response.text || "분석 결과를 생성할 수 없습니다.",
        sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks
      };
    } catch (error: any) {
      console.error("Gemini Error:", error);
      return { text: "상담원이 잠시 자리를 비웠습니다. 교재 정보를 직접 확인해 보세요." };
    }
  }
}

export const geminiService = new GeminiService();
