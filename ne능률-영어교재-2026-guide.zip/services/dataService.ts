
import { Page, SubBook, MultimediaResource, PageDetails, LevelStats, NextRecommendation } from '../types';
import * as XLSX from 'xlsx';

export class DataService {
  private transformImageUrl(url: string): string {
    if (!url) return '';
    const trimmed = String(url).trim();
    if (trimmed.includes('drive.google.com')) {
      const match = trimmed.match(/\/d\/(.+?)\/(view|edit|usp)/) || trimmed.match(/id=(.+?)(&|$)/);
      if (match && match[1]) {
        return `https://drive.google.com/uc?export=view&id=${match[1]}`;
      }
    }
    return trimmed;
  }

  private getVal(row: any, searchKeys: string[]): any {
    if (!row) return undefined;
    const rowKeys = Object.keys(row);
    // 검색 키워드 정규화 (소문자, 공백 제거)
    const normalizedSearchKeys = searchKeys.map(k => k.toLowerCase().replace(/\s/g, ''));
    
    // 1순위: 정확히 일치하는 키 찾기
    let actualKey = rowKeys.find(rk => {
      const normalizedRK = rk.toLowerCase().replace(/\s/g, '');
      return normalizedSearchKeys.includes(normalizedRK);
    });

    // 2순위: 포함 관계 검색
    if (!actualKey) {
      actualKey = rowKeys.find(rk => {
        const normalizedRK = rk.toLowerCase().replace(/\s/g, '');
        return normalizedSearchKeys.some(sk => normalizedRK.includes(sk) || sk.includes(normalizedRK));
      });
    }
    
    const value = actualKey ? row[actualKey] : undefined;
    return value !== undefined ? String(value).trim() : undefined;
  }

  private isMatch(val1: any, val2: any): boolean {
    if (val1 === undefined || val2 === undefined) return false;
    const s1 = String(val1).trim().toLowerCase().replace(/\s/g, '');
    const s2 = String(val2).trim().toLowerCase().replace(/\s/g, '');
    return s1 !== '' && s2 !== '' && (s1 === s2 || s1.includes(s2) || s2.includes(s1));
  }

  async parseExcelFile(file: File): Promise<Page[]> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = new Uint8Array(e.target?.result as ArrayBuffer);
          const workbook = XLSX.read(data, { type: 'array' });
          
          const mainSheetName = workbook.SheetNames[0];
          const detailSheetName = workbook.SheetNames[1]; // 시트 2: 상세 정보 (SubBooks)
          const resourceSheetName = workbook.SheetNames[2]; // 시트 3: 멀티미디어 자료

          const mainJson = XLSX.utils.sheet_to_json(workbook.Sheets[mainSheetName]) as any[];
          const detailJson = detailSheetName ? XLSX.utils.sheet_to_json(workbook.Sheets[detailSheetName]) as any[] : [];
          const resourceJson = resourceSheetName ? XLSX.utils.sheet_to_json(workbook.Sheets[resourceSheetName]) as any[] : [];

          if (!mainJson || mainJson.length === 0) {
            throw new Error("엑셀 파일의 첫 번째 시트(교재 목록)에서 데이터를 찾을 수 없습니다.");
          }

          const pages: Page[] = [];

          // 앞표지 추가
          pages.push({ 
            type: 'front', 
            title: '2026 NE능률 영어 가이드북', 
            content: '대한민국 영어 교육의 기준 - 초등부터 수능까지,\nNE능률이 제안하는 완벽한 학습 로드맵입니다.', 
            bg: 'bg-[#E83827]', 
            text: 'text-white' 
          });

          mainJson.forEach((row) => {
            const title = this.getVal(row, ['교재명', 'title', '교재 이름', '메인교재']);
            if (!title) return;

            // 시트 2: 서브 교재 정보 매핑
            const subBooks: SubBook[] = detailJson
              .filter(d => this.isMatch(this.getVal(d, ['교재명', '메인교재', '메인 교재']), title))
              .map(d => ({
                title: String(this.getVal(d, ['서브명', '단계명', 'title', '서브교재명']) || title),
                step: String(this.getVal(d, ['단계', '레벨', 'step', '레벨명']) || ''),
                target: String(this.getVal(d, ['대상', '학년', 'target']) || ''),
                pages: String(this.getVal(d, ['페이지', '쪽수', 'pages']) || ''),
                price: String(this.getVal(d, ['가격', '정가', 'price']) || '')
              }));

            // 시트 3: 멀티미디어 자료 매핑
            const resources: MultimediaResource[] = resourceJson
              .filter(r => this.isMatch(this.getVal(r, ['교재명', '메인교재', '메인 교재']), title))
              .map((r, idx) => ({
                id: idx,
                label: String(this.getVal(r, ['자료명', 'label', '자료 이름']) || '학습 자료'),
                type: (String(this.getVal(r, ['유형', 'type', '종류']) || 'doc').toLowerCase() as any),
                url: String(this.getVal(r, ['URL', 'link', '링크']) || '#'),
                desc: String(this.getVal(r, ['설명', 'desc', '자료 설명']) || '')
              }));

            const rawNextRecs = String(this.getVal(row, ['후속교재상세', '후속추천', 'recommendations']) || '');
            const nextRecommendations: NextRecommendation[] = rawNextRecs
              .split('|')
              .map(item => {
                const parts = item.split(':');
                if (parts.length >= 2) {
                  return { category: parts[0].trim(), books: parts[1].trim() };
                }
                return null;
              })
              .filter(Boolean) as NextRecommendation[];

            const details: PageDetails = {
              price: String(this.getVal(row, ['정가', '가격', 'price']) || ''),
              target: String(this.getVal(row, ['대상', '학년', 'target']) || ''),
              nelt: String(this.getVal(row, ['영역', 'category']) || ''),
              recommendation: String(this.getVal(row, ['전문가평', '전문가한마디', '전문가 한마디']) || ''),
              recommendationTarget: String(this.getVal(row, ['추천대상', '추천 대상 문구', '상세추천대상']) || ''),
              features: String(this.getVal(row, ['특징', 'features']) || '').split(/[|\n•]/).map(s => s.trim()).filter(s => s),
              levelStats: {
                vocabulary: parseInt(this.getVal(row, ['어휘', '난이도'])) || 0,
                grammar: parseInt(this.getVal(row, ['문법'])) || 0,
                reading: parseInt(this.getVal(row, ['독해'])) || 0,
                overallNelt: parseInt(this.getVal(row, ['nel레벨', 'nelt', '레벨'])) || 1
              },
              roadmap: {
                prev: String(this.getVal(row, ['이전', '선행']) || ''),
                currentLabel: String(this.getVal(row, ['현재']) || title),
                next: String(this.getVal(row, ['다음', '후속']) || '')
              },
              nextRecommendations,
              subBooks,
              resources
            };

            pages.push({
              type: 'body',
              title: String(title),
              content: String(this.getVal(row, ['홍보', '문구', '홍보문구']) || ''),
              image: this.transformImageUrl(this.getVal(row, ['이미지', '표지', 'cover'])),
              details
            });
          });

          // 뒷표지 추가
          pages.push({ 
            type: 'back', 
            title: '2026 NE능률 커리큘럼 완성', 
            content: '성공적인 영어 학습의 여정, NE능률이 끝까지 함께하겠습니다.', 
            bg: 'bg-slate-900', 
            text: 'text-white' 
          });

          resolve(pages);
        } catch (err: any) {
          reject(err);
        }
      };
      reader.onerror = () => reject(new Error("파일을 읽는 중 오류가 발생했습니다."));
      reader.readAsArrayBuffer(file);
    });
  }

  saveToLocal(pages: Page[]) {
    localStorage.setItem('ne_guide_data_2026', JSON.stringify(pages));
    localStorage.setItem('ne_guide_sync_time', new Date().toLocaleString());
  }

  loadFromLocal(): Page[] | null {
    const data = localStorage.getItem('ne_guide_data_2026');
    if (!data) return null;
    try {
      const parsed = JSON.parse(data);
      return Array.isArray(parsed) && parsed.length > 0 ? parsed : null;
    } catch {
      return null;
    }
  }

  getLastSyncTime(): string | null {
    return localStorage.getItem('ne_guide_sync_time');
  }

  clearLocal() {
    localStorage.removeItem('ne_guide_data_2026');
    localStorage.removeItem('ne_guide_sync_time');
  }
}

export const dataService = new DataService();
