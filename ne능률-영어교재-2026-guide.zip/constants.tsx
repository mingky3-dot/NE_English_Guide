
import { Page } from './types';

export const BRAND_COLOR = "#E83827";

export const PAGES: Page[] = [
  { 
    type: 'front', 
    title: '2026 NE능률 영어 가이드북', 
    content: '대한민국 영어 교육의 기준 - 초등부터 수능까지,\nNE능률이 제안하는 완벽한 학습 로드맵입니다.', 
    bg: 'bg-[#E83827]', 
    text: 'text-white' 
  },
  { 
    type: 'body', 
    title: '능률 VOCA 어원편', 
    content: '어휘 학습의 스테디셀러, 1,000만 부의 선택', 
    image: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&q=80&w=800',
    details: {
      price: '15,000원',
      target: '중3 ~ 고2',
      nelt: 'VOCABULARY',
      recommendation: '어근과 접사를 통해 단어의 생성 원리를 이해하면 암기 효율이 3배 이상 높아집니다.',
      features: [
        '핵심 어근 60개로 1,500여 개 필수 어휘 정복',
        '그림과 어원 풀이로 기억에 오래 남는 암기법',
        '수능 및 모의고사 최신 빈출 어휘 완벽 반영'
      ],
      resources: [
        { id: 0, label: '어원편 전체 MP3', type: 'audio', url: '#', desc: '표제어와 뜻이 포함된 음원 파일' },
        { id: 1, label: '단어/뜻 테스트지', type: 'test', url: '#', desc: '출력하여 바로 사용하는 자가 진단지' }
      ],
      subBooks: [
        { title: '능률 VOCA 입문편', step: 'Level 1', target: '예비중~중1', pages: '320p', price: '13,000원' },
        { title: '능률 VOCA 기본편', step: 'Level 2', target: '중2~중3', pages: '352p', price: '14,000원' },
        { title: '능률 VOCA 어원편', step: 'Level 3', target: '중3~고2', pages: '368p', price: '15,000원' }
      ],
      levelStats: { vocabulary: 95, grammar: 10, reading: 40, overallNelt: 7 },
      roadmap: { prev: '중학 능률 VOCA', currentLabel: '어원편', next: '능률 VOCA 고난도' },
      nextRecommendations: [
        { category: '어휘 심화', books: '능률 VOCA 고난도, 수능 실전편' },
        { category: '독해 연계', books: 'Reading Expert 1, 2' }
      ]
    }
  },
  { 
    type: 'body', 
    title: 'Grammar Inside', 
    content: '개념 이해부터 서술형 대비까지 가장 완벽한 문법서', 
    image: 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?auto=format&fit=crop&q=80&w=800',
    details: {
      price: '14,500원',
      target: '중학교 1-3학년',
      nelt: 'GRAMMAR',
      recommendation: '문법은 단순 암기가 아니라 문장의 구조를 이해하는 틀입니다. 연습문제 비중이 높아 실전 감각을 키우기 좋습니다.',
      features: [
        '최신 중학 교과서 핵심 문법 요소 완벽 분석',
        '내신 만점을 위한 고난도 서술형 문제 강화',
        'Review Test를 통한 체계적인 누적 복습'
      ],
      resources: [
        { id: 0, label: '핵심 개념 강의 영상', type: 'video', url: '#', desc: '선생님이 직접 설명해주는 문법 포인트' },
        { id: 1, label: '내신 기출 예상 문제', type: 'test', url: '#', desc: '시험 전 꼭 풀어봐야 할 실전 문제' }
      ],
      subBooks: [
        { title: 'Grammar Inside Starter', step: '입문', target: '예비중', pages: '168p', price: '13,000원' },
        { title: 'Grammar Inside Lv.1', step: '기초', target: '중1', pages: '184p', price: '14,500원' }
      ],
      levelStats: { vocabulary: 35, grammar: 98, reading: 45, overallNelt: 5 },
      roadmap: { prev: '초등 문법 톡톡', currentLabel: 'Grammar Inside 1', next: 'Grammar Inside 2' },
      nextRecommendations: [
        { category: '문법 기본기', books: 'Grammar Zone 고등 기본, 고등 필수' },
        { category: '내신 및 서술형 대비', books: '중학 영문법 총정리 모의고사, 필히 통하는 고등 영문법 / 서술형' }
      ]
    }
  },
  { 
    type: 'body', 
    title: 'Reading Expert', 
    content: '수능을 앞둔 중학생을 위한 비문학 독해의 바이블', 
    image: 'https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&q=80&w=800',
    details: {
      price: '13,000원',
      target: '중학 상위권 ~ 예비고',
      nelt: 'READING',
      recommendation: '독해는 글의 논리 구조를 파악하는 훈련입니다. 다양한 분야의 지문을 접하며 배경지식을 넓히는 것이 중요합니다.',
      features: [
        '최신 수능/모평 비문학 유형 최적화 지문',
        '인문, 사회, 과학, 예술 등 융합형 소재 수록'
      ],
      resources: [
        { id: 0, label: '전 지문 직독직해 워크시트', type: 'doc', url: '#', desc: '지문 분석력을 높여주는 보충 자료' }
      ],
      subBooks: [
        { title: 'Reading Expert 1', step: '기초', target: '중1-2', pages: '160p', price: '13,000원' }
      ],
      levelStats: { vocabulary: 70, grammar: 50, reading: 95, overallNelt: 6 },
      roadmap: { prev: 'Reading Inside', currentLabel: 'Expert 1', next: 'Expert 2' },
      nextRecommendations: [
        { category: '수능 대비', books: '수능 실전 독해, 6/9월 모의고사 분석' },
        { category: '어휘 연계', books: '능률 VOCA 어원편, 숙어편' }
      ]
    }
  },
  { 
    type: 'back', 
    title: '2026 NE능률 커리큘럼 완성', 
    content: '성공적인 영어 학습의 여정, NE능률이 끝까지 함께하겠습니다.', 
    bg: 'bg-slate-900', 
    text: 'text-white' 
  },
];
