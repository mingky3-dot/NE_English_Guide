
import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { 
  BookOpen, 
  ChevronLeft, 
  ChevronRight, 
  Menu, 
  PlayCircle, 
  X, 
  Zap, 
  Book as BookIcon, 
  Square, 
  Columns2, 
  FileText, 
  Headphones, 
  Quote, 
  Users, 
  Info, 
  Trophy, 
  ArrowRight, 
  Video,
  Link as LinkIcon,
  RefreshCw,
  Upload,
  Database,
  RotateCcw,
  Check,
  Lock,
  MessageSquare,
  ExternalLink,
  AlertCircle,
  Maximize2,
  List as ListIcon,
  Clock,
  Layers,
  ShoppingCart,
  Sparkles
} from 'lucide-react';
import { PAGES as FALLBACK_PAGES, BRAND_COLOR } from './constants';
import Markdown from 'react-markdown';
import { Page, Chapter, MultimediaResource } from './types';
import { geminiService } from './services/geminiService';
import { dataService } from './services/dataService';

const App: React.FC = () => {
  const [pages, setPages] = useState<Page[]>(() => {
    const localData = dataService.loadFromLocal();
    return (localData && localData.length > 0) ? localData : FALLBACK_PAGES;
  });
  
  const [currentPage, setCurrentPage] = useState(0);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeModal, setActiveModal] = useState<'info' | 'multimedia' | 'data-manage' | 'ai-consult' | null>(null); 
  const [viewMode, setViewMode] = useState<'single' | 'double'>('single');
  const [isMobile, setIsMobile] = useState(false);
  
  const [adminPassword, setAdminPassword] = useState('');
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [authError, setAuthError] = useState(false);

  // AI Consultation States
  const [aiQuery, setAiQuery] = useState('');
  const [aiResponse, setAiResponse] = useState<string | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [aiSources, setAiSources] = useState<any[]>([]);
  
  const [selectedResource, setSelectedResource] = useState<MultimediaResource | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [lastSyncTime, setLastSyncTime] = useState<string | null>(dataService.getLastSyncTime());
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const checkMobile = () => {
      const mobile = window.innerWidth < 1024;
      setIsMobile(mobile);
      if (mobile) setViewMode('single');
    };
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  useEffect(() => {
    if (activeModal === 'multimedia' && currentResources.length > 0 && !selectedResource && !isMobile) {
      setSelectedResource(currentResources[0]);
    }
    if (!activeModal) {
      setSelectedResource(null);
    }
  }, [activeModal, isMobile]);

  const handleAdminAuth = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminPassword === '2026') {
      setIsAuthorized(true);
      setAuthError(false);
    } else {
      setAuthError(true);
      setAdminPassword('');
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const newPages = await dataService.parseExcelFile(file);
      setPages(newPages);
      dataService.saveToLocal(newPages);
      const syncTime = dataService.getLastSyncTime();
      setLastSyncTime(syncTime);
      setCurrentPage(0);
      alert(`🎉 데이터 동기화 완료!\n\n${newPages.filter(p => p.type === 'body').length}개의 교재 정보가 업데이트 되었습니다.\n동기화 시각: ${syncTime}`);
    } catch (err: any) {
      console.error(err);
      alert(`업로드 실패: ${err.message || '파일 형식을 확인해주세요.'}`);
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const resetData = () => {
    if (confirm('모든 사용자 데이터를 초기화하고 기본 가이드북 설정으로 복원하시겠습니까?')) {
      dataService.clearLocal();
      setPages(FALLBACK_PAGES);
      setLastSyncTime(null);
      setCurrentPage(0);
      setActiveModal(null);
      alert('데이터가 성공적으로 초기화되었습니다.');
    }
  };

  const chapters: Chapter[] = useMemo(() => 
    pages.map((p, i) => ({ name: p.title, index: i })), 
  [pages]);

  const nextMove = () => {
    const step = viewMode === 'double' ? 2 : 1;
    if (currentPage + step < pages.length) setCurrentPage(currentPage + step);
    else if (currentPage < pages.length - 1) setCurrentPage(pages.length - 1);
  };

  const prevMove = () => {
    const step = viewMode === 'double' ? 2 : 1;
    if (currentPage - step >= 0) setCurrentPage(currentPage - step);
    else if (currentPage > 0) setCurrentPage(0);
  };

  const handleAiConsult = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiQuery.trim() || isAiLoading) return;

    setIsAiLoading(true);
    setAiResponse(null);
    setAiSources([]);

    try {
      const result = await geminiService.recommendBook(aiQuery, pages);
      setAiResponse(result.text);
      if (result.sources) setAiSources(result.sources);
    } catch (error) {
      console.error(error);
      setAiResponse("상담 중 오류가 발생했습니다. 잠시 후 다시 시도해주세요.");
    } finally {
      setIsAiLoading(false);
    }
  };

  const displayPages = useMemo(() => {
    if (pages.length === 0) return [];
    if (viewMode === 'single') return [currentPage];
    if (currentPage === 0) return [0];
    if (currentPage === pages.length - 1) return [pages.length - 1];
    const left = currentPage % 2 === 0 ? currentPage : currentPage - 1;
    const right = left + 1;
    return right < pages.length ? [left, right] : [left];
  }, [currentPage, viewMode, pages.length]);

  const currentResources: MultimediaResource[] = useMemo(() => {
    if (!pages[currentPage]) return [];
    return pages[currentPage].details?.resources || [];
  }, [currentPage, pages]);

  const getResourceIcon = (type: string, size: number = 20) => {
    const t = (type || 'doc').toLowerCase();
    switch (t) {
      case 'audio': return <Headphones size={size} />;
      case 'doc': return <FileText size={size} />;
      case 'test': return <Zap size={size} />;
      case 'video': return <Video size={size} />;
      case 'link': return <LinkIcon size={size} />;
      default: return <FileText size={size} />;
    }
  };

  const getResourceColor = (type: string) => {
    const t = (type || 'doc').toLowerCase();
    switch (t) {
      case 'audio': return BRAND_COLOR;
      case 'doc': return '#0F172A';
      case 'test': return '#F59E0B';
      case 'video': return '#3B82F6';
      case 'link': return '#10B981';
      default: return '#64748b';
    }
  };

  const getDifficultyLabel = (val: number) => {
    if (val >= 80) return '상';
    if (val >= 60) return '중상';
    if (val >= 40) return '중';
    if (val >= 20) return '중하';
    return '하';
  };

  return (
    <div className="flex flex-col h-screen bg-[#f1f5f9] font-sans text-slate-800 overflow-hidden select-none">
      
      <header className="flex items-center justify-between px-2 md:px-6 py-2 md:py-4 bg-white/80 backdrop-blur-md shadow-sm z-30 border-b border-slate-200">
        <div className="flex items-center gap-1.5 md:gap-4 cursor-pointer group" onClick={() => setCurrentPage(0)}>
          <div className="p-1 md:p-2 rounded-lg md:rounded-2xl shadow-lg shadow-red-100 flex items-center justify-center transition-transform group-hover:scale-110" style={{ backgroundColor: BRAND_COLOR }}>
            <BookOpen size={14} className="text-white md:w-[18px] md:h-[18px]" />
          </div>
          <div>
            <h1 className="font-black text-xs sm:text-sm md:text-xl tracking-tighter text-slate-900 leading-none">NE능률</h1>
            <p className="text-[6px] sm:text-[8px] md:text-[10px] font-black uppercase tracking-[0.1em] md:tracking-[0.2em] mt-0.5 md:mt-1" style={{ color: BRAND_COLOR }}>영어교재 2026 Guide</p>
          </div>
        </div>
        
        <div className="flex items-center gap-1 md:gap-4">
          <a 
            href="https://smartstore.naver.com/nebook" 
            target="_blank" 
            rel="noreferrer"
            className="flex items-center gap-1 md:gap-2 px-2 py-1.5 md:px-4 md:py-2.5 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-all text-[9px] md:text-[11px] font-black text-slate-600 shadow-sm whitespace-nowrap"
          >
            <ShoppingCart size={12} className="text-red-500 md:w-3.5 md:h-3.5" /> <span>교재 주문</span>
          </a>

          <button 
            onClick={() => { setActiveModal('ai-consult'); setAiQuery(''); setAiResponse(null); }}
            className="flex items-center gap-1 md:gap-2 px-2 py-1.5 md:px-4 md:py-2.5 bg-slate-900 text-white rounded-xl hover:bg-black transition-all text-[9px] md:text-[11px] font-black shadow-sm whitespace-nowrap"
          >
            <Sparkles size={12} className="text-red-500 md:w-3.5 md:h-3.5" /> <span>AI 상담</span>
          </button>

          <button 
            onClick={() => { setActiveModal('data-manage'); setIsAuthorized(false); }}
            className="hidden lg:flex items-center gap-2 px-4 py-2.5 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-all text-[11px] font-black text-slate-600 shadow-sm"
          >
            <Database size={14} /> 데이터 관리
          </button>
          
          {!isMobile && (
            <button 
              onClick={() => setViewMode(viewMode === 'double' ? 'single' : 'double')}
              className="px-3 py-2.5 hover:bg-slate-100 rounded-xl transition-all border border-slate-100 flex items-center gap-2 text-[11px] font-black text-slate-600"
            >
              {viewMode === 'double' ? <Square size={16} /> : <Columns2 size={16} />} 
              {viewMode === 'double' ? 'Single' : 'Spread'}
            </button>
          )}
          <button onClick={() => setIsMenuOpen(true)} className="p-2 md:p-2.5 hover:bg-slate-100 rounded-xl border border-slate-100">
            <Menu size={18} />
          </button>
        </div>
      </header>

      <main className="flex-1 relative flex items-center justify-center p-2 md:p-6 lg:p-8 xl:p-10 bg-[#f8fafc] overflow-hidden">
        <div className={`flex gap-4 lg:gap-8 w-full h-full items-center justify-center transition-all duration-700 ease-in-out ${viewMode === 'double' ? 'flex-row max-w-[1400px] xl:max-w-[1600px]' : 'flex-col max-w-[700px] xl:max-w-[850px]'}`}>
          {displayPages.map((idx) => {
            const page = pages[idx];
            if (!page) return null;
            const bodyPageIndex = pages.slice(0, idx + 1).filter(p => p.type === 'body').length;
            return (
              <div key={idx} className={`flex-1 h-full max-h-[92vh] md:max-h-[88vh] xl:max-h-[90vh] w-full shadow-2xl overflow-hidden flex flex-col relative transition-all duration-700 ${page.bg || 'bg-white'} ${page.text || 'text-slate-800'} rounded-[1.5rem] md:rounded-[3rem] xl:rounded-[4rem] border border-slate-100/50`}>
                <div className="p-4 md:p-6 lg:p-6 xl:p-8 flex flex-col h-full">
                  <div className="flex justify-between items-center mb-2 md:mb-4 lg:mb-4">
                    <div className="text-[9px] md:text-[10px] lg:text-xs font-black uppercase tracking-[0.2em] opacity-40">
                      {page.type === 'front' ? 'WELCOME' : page.type === 'back' ? 'FINISH' : `PAGE ${bodyPageIndex}`}
                    </div>
                    {page.details?.nelt && (
                      <div className="text-white px-3 py-1 md:px-5 md:py-2 rounded-full text-[9px] md:text-[11px] lg:text-xs font-black tracking-tight shadow-lg shadow-red-200" style={{ backgroundColor: BRAND_COLOR }}>
                        {page.details.nelt}
                      </div>
                    )}
                  </div>
                  
                  <div className={`grid ${page.type !== 'body' ? 'grid-cols-1' : 'grid-cols-[80px_1fr] md:grid-cols-[150px_1fr] lg:grid-cols-[180px_1fr] xl:grid-cols-[220px_1fr]'} gap-4 md:gap-6 lg:gap-8 mb-3 md:mb-5 lg:mb-5`}>
                     {page.image && (
                        <div className="aspect-[3/4.2] overflow-hidden rounded-lg md:rounded-2xl lg:rounded-3xl shadow-2xl border-2 md:border-4 lg:border-4 border-white transform hover:rotate-1 hover:scale-[1.02] transition-all duration-500 shadow-slate-200/50">
                           <img src={page.image} alt={page.title} className="w-full h-full object-cover" />
                        </div>
                     )}
                     <div className={page.type !== 'body' ? 'text-center pt-4 md:pt-6 lg:pt-8' : 'text-left pt-1'}>
                        <h2 className="font-black mb-1 md:mb-2 lg:mb-2 leading-[1.05] tracking-tighter text-xl md:text-3xl lg:text-4xl xl:text-5xl">{page.title}</h2>
                        <p className="opacity-60 font-medium italic text-xs md:text-sm lg:text-base xl:text-lg break-keep whitespace-pre-wrap leading-relaxed">"{page.content}"</p>
                        {page.type === 'body' && (
                          <div className="mt-2 md:mt-4 lg:mt-4 flex flex-wrap items-center gap-2 md:gap-4">
                            <div className="px-2.5 py-1.5 md:px-4 md:py-2 bg-red-50 text-red-600 rounded-lg md:rounded-xl flex items-center gap-1.5 md:gap-2 border border-red-100 shadow-sm">
                               <Users size={12} className="md:w-4 md:h-4" />
                               <span className="text-[9px] md:text-xs lg:text-sm font-black">{page.details?.target || '전대상'}</span>
                            </div>
                            <div className="px-2.5 py-1.5 md:px-4 md:py-2 bg-slate-900 text-white rounded-lg md:rounded-xl flex items-center gap-1.5 md:gap-2 shadow-xl shadow-slate-200">
                               <Trophy size={12} className="text-yellow-400 md:w-4 md:h-4" />
                               <span className="text-[9px] md:text-xs lg:text-sm font-black">NELT {page.details?.levelStats?.overallNelt || '1'}</span>
                            </div>
                          </div>
                        )}
                     </div>
                  </div>
                  
                  <div className={`flex-1 overflow-y-auto no-scrollbar pr-1 pb-2 ${page.type === 'body' ? 'lg:grid lg:grid-cols-2 lg:gap-4 xl:gap-6 lg:overflow-y-hidden' : 'space-y-4 md:space-y-8 lg:space-y-12'}`}>
                    {page.details?.recommendation && (
                      <div className="p-4 md:p-5 lg:p-5 xl:p-6 bg-slate-50/50 rounded-[1.2rem] md:rounded-[2rem] lg:rounded-[2rem] border border-slate-100 flex gap-3 md:gap-4 lg:gap-4 items-start shadow-inner h-fit">
                        <span className="text-red-500 shrink-0 mt-1 opacity-20"><Quote size={24} className="md:w-8 md:h-8 lg:w-10 lg:h-10" /></span>
                        <div className="text-xs md:text-sm lg:text-base xl:text-lg font-black text-slate-700 leading-relaxed break-keep">
                          <Markdown
                            components={{
                              a: ({ node, ...props }) => {
                                const href = props.href || '';
                                if (href.startsWith('book://')) {
                                  const bookTitle = decodeURIComponent(href.replace('book://', ''));
                                  const pageIndex = pages.findIndex(p => p.title.includes(bookTitle) || bookTitle.includes(p.title));
                                  if (pageIndex !== -1) {
                                    return (
                                      <button
                                        onClick={() => {
                                          setCurrentPage(pageIndex);
                                          setActiveModal('info');
                                        }}
                                        className="text-red-600 hover:underline font-black"
                                      >
                                        {props.children}
                                      </button>
                                    );
                                  }
                                }
                                return <a {...props} className="text-red-400 underline" />;
                              }
                            }}
                          >
                            {page.details.recommendation.replace(/\[\[(.*?)\]\]/g, '[$1](book://$1)')}
                          </Markdown>
                        </div>
                      </div>
                    )}
                    {page.details?.features && page.details.features.length > 0 && (
                      <div className="p-4 md:p-5 lg:p-5 xl:p-6 bg-white rounded-[1.2rem] md:rounded-[2rem] lg:rounded-[2rem] border border-slate-100 shadow-sm h-fit">
                         <h4 className="text-[9px] md:text-[10px] lg:text-[10px] font-black text-slate-300 uppercase tracking-widest mb-2 md:mb-3 lg:mb-4">시리즈 핵심 특장점</h4>
                         <ul className="space-y-2 md:space-y-3 lg:space-y-3">
                            {page.details.features.map((f, i) => (
                               <li key={i} className="flex gap-2 md:gap-3 lg:gap-3 text-xs md:text-sm lg:text-sm xl:text-base font-bold text-slate-600 leading-snug items-start group">
                                  <div className="w-5 h-5 md:w-6 md:h-6 lg:w-6 lg:h-6 rounded-full bg-red-50 flex items-center justify-center shrink-0 border border-red-100 shadow-sm group-hover:scale-110 transition-transform">
                                    <span className="text-[9px] md:text-xs lg:text-xs font-black text-red-600">{i + 1}</span>
                                  </div>
                                  <span className="pt-0.5">{f}</span>
                                </li>
                            ))}
                         </ul>
                      </div>
                    )}
                  </div>
                  
                  {page.type === 'body' && (
                    <div className="mt-auto pt-3 md:pt-5 lg:pt-6 border-t border-slate-100 flex gap-2 md:gap-4">
                      <button onClick={() => setActiveModal('info')} className="flex-1 py-3 md:py-4 lg:py-5 bg-slate-900 text-white rounded-xl md:rounded-[1.2rem] lg:rounded-[1.5rem] flex items-center justify-center gap-1.5 md:gap-2 text-[10px] md:text-xs lg:text-sm font-black shadow-xl hover:bg-black hover:scale-[1.02] active:scale-95 transition-all">
                        <Zap size={16} className="text-yellow-400 md:w-4 md:h-4 lg:w-5 lg:h-5" /> <span className="hidden xs:inline">상세 분석 리포트</span><span className="xs:hidden">상세 보기</span>
                      </button>
                      <button 
                        onClick={() => {
                          const pdfRes = currentResources.find(r => r.type === 'doc' || r.type === 'test');
                          if (pdfRes) setSelectedResource(pdfRes);
                          setActiveModal('multimedia');
                        }} 
                        className="flex-1 py-3 md:py-4 lg:py-5 bg-white border-2 border-slate-200 text-slate-800 rounded-xl md:rounded-[1.2rem] lg:rounded-[1.5rem] flex items-center justify-center gap-1.5 md:gap-2 text-[10px] md:text-xs lg:text-sm font-black hover:bg-slate-50 hover:border-slate-300 hover:scale-[1.02] active:scale-95 transition-all shadow-sm"
                      >
                        <PlayCircle size={16} style={{ color: BRAND_COLOR }} className="md:w-4 md:h-4 lg:w-5 lg:h-5" /> <span className="hidden xs:inline">미리보기</span><span className="xs:hidden">미리보기</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {!isMobile && (
          <button onClick={prevMove} disabled={currentPage === 0} className="absolute left-4 md:left-10 z-20 p-4 md:p-5 bg-white rounded-full shadow-2xl disabled:opacity-0 hover:scale-110 transition-all border border-slate-100 group">
            <ChevronLeft size={20} className="md:w-6 md:h-6 group-hover:-translate-x-1 transition-transform" />
          </button>
        )}
        {!isMobile && (
          <button onClick={nextMove} disabled={currentPage === pages.length - 1} className="absolute right-4 md:right-10 z-20 p-4 md:p-5 bg-white rounded-full shadow-2xl disabled:opacity-0 hover:scale-110 transition-all border border-slate-100 group">
            <ChevronRight size={20} className="md:w-6 md:h-6 group-hover:translate-x-1 transition-transform" />
          </button>
        )}
      </main>

      <footer className="bg-white/80 backdrop-blur-md border-t px-4 md:px-6 py-2 md:py-4 flex flex-col items-center gap-1.5 md:gap-3 z-30">
        <div className="w-full max-w-lg flex items-center gap-3">
          <span className="text-[8px] md:text-[10px] font-black text-slate-200">PROGRESS</span>
          <div className="flex-1 h-1 md:h-1.5 bg-slate-100 rounded-full overflow-hidden shadow-inner">
            <div className="h-full transition-all duration-700 ease-out" style={{ width: `${((currentPage + 1) / pages.length) * 100}%`, backgroundColor: BRAND_COLOR }} />
          </div>
          <span className="text-[8px] md:text-[10px] font-black text-slate-200">{Math.round(((currentPage + 1) / pages.length) * 100)}%</span>
        </div>
        <div className="flex items-center gap-6 md:gap-8 text-[9px] md:text-[11px] font-black text-slate-400 uppercase tracking-widest">
          <button onClick={prevMove} className="hover:text-slate-900 transition-colors py-1">PREV</button>
          <span className="text-slate-900 px-3 py-1 md:px-5 md:py-2 bg-slate-50 rounded-full border border-slate-100 font-black shadow-sm">{currentPage + 1} / {pages.length}</span>
          <button onClick={nextMove} className="hover:text-slate-900 transition-colors py-1">NEXT</button>
        </div>
      </footer>

      {activeModal && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-0.5 md:p-4 lg:p-8 overflow-hidden">
          <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-xl animate-in fade-in duration-500" onClick={() => setActiveModal(null)} />
          <div className={`relative w-full ${['info', 'multimedia', 'data-manage'].includes(activeModal) ? 'max-w-[1600px]' : 'max-w-2xl'} bg-white rounded-[1rem] md:rounded-[3rem] lg:rounded-[4rem] shadow-[0_0_100px_rgba(0,0,0,0.2)] flex flex-col h-[98vh] md:h-[92vh] max-h-[98vh] animate-in zoom-in-95 slide-in-from-bottom-10 duration-700 ease-out`}>
            
            <div className="p-4 md:p-8 lg:p-12 border-b flex items-center justify-between bg-white rounded-t-[1rem] md:rounded-t-[3rem] lg:rounded-t-[4rem] shrink-0">
               <div className="flex items-center gap-3 md:gap-6 lg:gap-8">
                  <div className="p-2 md:p-5 lg:p-6 bg-slate-50 shadow-inner text-red-500 rounded-lg md:rounded-3xl lg:rounded-[2rem] border border-slate-100 transform -rotate-3 hover:rotate-0 transition-transform duration-500">
                    {activeModal === 'info' ? <Info size={16} className="md:w-8 md:h-8 lg:w-10 lg:h-10"/> : activeModal === 'data-manage' ? <Database size={16} className="md:w-8 md:h-8 lg:w-10 lg:h-10"/> : activeModal === 'ai-consult' ? <Sparkles size={16} className="md:w-8 md:h-8 lg:w-10 lg:h-10"/> : <PlayCircle size={16} className="md:w-8 md:h-8 lg:w-10 lg:h-10"/>}
                  </div>
                  <div>
                    <h3 className="text-sm md:text-3xl lg:text-4xl font-black text-slate-900 tracking-tighter leading-tight">
                      {activeModal === 'info' ? '교재 상세 분석' : activeModal === 'data-manage' ? '시스템 관리' : activeModal === 'ai-consult' ? 'AI 1:1 맞춤 상담' : '미리보기'}
                    </h3>
                    <p className="text-[7px] md:text-xs lg:text-sm font-bold text-slate-400 uppercase tracking-[0.1em] md:tracking-[0.3em] mt-0.5 lg:mt-1">
                      {activeModal === 'data-manage' ? 'Excel Data Sync' : activeModal === 'ai-consult' ? 'NE능률 AI 수석 상담원' : pages[currentPage]?.title}
                    </p>
                  </div>
               </div>
               <button onClick={() => setActiveModal(null)} className="p-2 md:p-5 lg:p-6 hover:bg-slate-100 rounded-full transition-all text-slate-400 hover:text-slate-900 hover:rotate-90 duration-300"><X size={24} className="md:w-8 md:h-8 lg:w-10 lg:h-10"/></button>
            </div>

            <div className="flex-1 overflow-hidden bg-white flex flex-col lg:flex-row">
              {activeModal === 'multimedia' ? (
                <div className="flex w-full h-full overflow-hidden flex-col lg:flex-row">
                  <div className={`${isMobile && selectedResource ? 'hidden' : 'flex'} w-full lg:w-[350px] xl:w-[420px] border-r border-slate-100 flex-col bg-slate-50/30 overflow-hidden shrink-0`}>
                    <div className="p-4 lg:px-10 lg:py-8 border-b border-slate-100">
                      <h4 className="text-[10px] lg:text-sm font-black text-slate-500 uppercase tracking-widest mb-1">Resource List</h4>
                      <p className="text-[8px] lg:text-[11px] font-bold text-slate-400 italic">"{currentResources.length}개의 자료"</p>
                    </div>
                    <div className="flex-1 overflow-y-auto p-3 lg:px-10 lg:py-8 space-y-3 lg:space-y-4 no-scrollbar">
                      {currentResources.map((item, idx) => (
                        <button 
                          key={idx} 
                          onClick={() => setSelectedResource(item)} 
                          className={`w-full p-4 lg:p-7 rounded-xl lg:rounded-[2.5rem] text-left transition-all border-2 flex items-center gap-3 lg:gap-4 group ${selectedResource?.id === item.id ? 'border-red-500 bg-white shadow-xl shadow-red-100' : 'border-transparent bg-white hover:bg-slate-100'}`}
                        >
                          <div className={`p-2.5 lg:p-4 rounded-lg lg:rounded-2xl shrink-0 transition-colors ${selectedResource?.id === item.id ? 'bg-red-500 text-white' : 'bg-slate-50 text-slate-400'}`} style={selectedResource?.id === item.id ? {} : { color: getResourceColor(item.type) }}>
                            {getResourceIcon(item.type, isMobile ? 16 : 20)}
                          </div>
                          <div className="min-w-0">
                            <h5 className={`font-black text-[11px] lg:text-lg tracking-tight truncate ${selectedResource?.id === item.id ? 'text-red-600' : 'text-slate-800'}`}>{item.label}</h5>
                            <p className="text-[7px] lg:text-[11px] font-bold text-slate-400 uppercase tracking-tighter mt-0.5">{item.type}</p>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className={`${isMobile && !selectedResource ? 'hidden' : 'flex'} flex-1 flex flex-col bg-white overflow-hidden p-2 lg:pr-10`}>
                    {selectedResource ? (
                      <div className="flex-1 flex flex-col lg:py-8 lg:pl-8">
                        <div className="p-3 lg:px-8 lg:py-5 bg-slate-50/80 backdrop-blur-md border border-slate-100 rounded-t-xl lg:rounded-t-[2rem] flex items-center justify-between shrink-0">
                          <div className="flex items-center gap-2 lg:gap-3">
                            {isMobile && (
                              <button onClick={() => setSelectedResource(null)} className="p-2 hover:bg-slate-200 rounded-full transition-colors">
                                <ListIcon size={16} className="text-slate-600" />
                              </button>
                            )}
                            <div className="flex flex-col">
                              <span className="text-[8px] lg:text-[11px] font-black text-red-600 flex items-center gap-1"><AlertCircle size={10} /> 자료가 보이지 않나요?</span>
                              <span className="text-slate-400 text-[7px] lg:text-[9px] font-bold">보안 정책 시 새 창 버튼 클릭</span>
                            </div>
                          </div>
                          <div className="flex items-center gap-2 lg:gap-3">
                            <a 
                              href={selectedResource.url} 
                              target="_blank" 
                              rel="noreferrer" 
                              className="px-3 py-1.5 lg:px-6 lg:py-3 bg-slate-900 text-white rounded-lg lg:rounded-2xl text-[8px] lg:text-xs font-black shadow-lg flex items-center gap-1.5 hover:bg-black transition-colors"
                            >
                              <ExternalLink size={12} /> <span className="hidden xs:inline">새 창에서 열기</span><span className="xs:hidden">새창</span>
                            </a>
                          </div>
                        </div>
                        <div className="flex-1 relative bg-slate-50 rounded-b-xl lg:rounded-b-[2rem] border-x border-b border-slate-100 overflow-hidden flex items-center justify-center shadow-inner">
                           {(() => {
                              const res = selectedResource;
                              if (!res.url || res.url === '#') return <div className="text-slate-300">연결 오류</div>;

                              const rawUrl = res.url;
                              const purePath = rawUrl.split(/[?#]/)[0].toLowerCase();
                              const isPdf = purePath.endsWith('.pdf') || rawUrl.toLowerCase().includes('.pdf');
                              const isDoc = res.type === 'doc' || res.type === 'test';
                              
                              const safeEncodedTargetUrl = encodeURIComponent(decodeURI(rawUrl));
                              const viewerUrl = (isPdf || isDoc) 
                                ? `https://docs.google.com/gview?embedded=true&url=${safeEncodedTargetUrl}`
                                : rawUrl;

                              if (res.type === 'audio') {
                                 return (
                                   <div className="w-full max-w-md p-6 md:p-10 flex flex-col items-center gap-6 md:gap-8 animate-in fade-in zoom-in duration-500">
                                      <div className="w-20 h-20 md:w-40 md:h-40 bg-white rounded-full flex items-center justify-center shadow-xl border-4 border-white animate-float">
                                         <Headphones size={32} className="text-red-500 md:w-20 md:h-20" />
                                      </div>
                                      <audio controls className="w-full h-10 md:h-12" key={rawUrl} src={rawUrl}>
                                         지원하지 않는 브라우저
                                      </audio>
                                      <div className="p-3 md:p-4 bg-white/60 rounded-xl md:rounded-2xl border border-slate-100 text-center">
                                         <p className="text-slate-500 text-[9px] md:text-xs font-medium italic">"{res.desc}"</p>
                                      </div>
                                   </div>
                                 );
                              }
                              if (res.type === 'video') {
                                 return (
                                   <div className="w-full h-full flex items-center justify-center animate-in fade-in duration-700 bg-black">
                                      <video controls className="max-w-full max-h-full" key={rawUrl} src={rawUrl} />
                                   </div>
                                 );
                              }
                              
                              return (
                                 <div className="w-full h-full relative">
                                    <object 
                                      key={viewerUrl}
                                      data={viewerUrl} 
                                      type={isPdf ? "application/pdf" : "text/html"} 
                                      className="w-full h-full"
                                    >
                                       <iframe 
                                         src={viewerUrl} 
                                         className="w-full h-full border-none" 
                                         title="Resource Viewer"
                                         allowFullScreen
                                       />
                                    </object>
                                 </div>
                              );
                           })()}
                        </div>
                      </div>
                    ) : (
                      <div className="flex-1 flex flex-col items-center justify-center gap-6 text-slate-300">
                        <div className="p-8 bg-slate-50 rounded-full border-4 border-slate-100 shadow-sm">
                          <Maximize2 size={64} className="text-slate-200" />
                        </div>
                        <div className="text-center">
                          <p className="font-black text-xl md:text-2xl tracking-tighter text-slate-400">자료를 선택해 주세요</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ) : activeModal === 'info' ? (
                <div className="flex-1 overflow-y-auto p-4 md:p-8 no-scrollbar bg-slate-50/30">
                  <div className="space-y-4 md:space-y-6 lg:space-y-8 pb-10 p-3 md:p-8 lg:p-12">
                       <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6 items-stretch">
                          <section className="p-4 md:p-6 lg:p-8 bg-white rounded-2xl md:rounded-[2rem] lg:rounded-[2.5rem] border border-slate-100 shadow-xl shadow-slate-200/50 flex flex-col h-full hover:shadow-2xl transition-shadow duration-500">
                             <div className="space-y-3 flex-1">
                                <div className="flex items-center gap-2 mb-1">
                                   <div className="p-1.5 md:p-2 bg-red-50 rounded-lg">
                                      <Users size={14} className="text-red-500 md:w-4 md:h-4" />
                                   </div>
                                   <span className="text-[7px] md:text-[10px] lg:text-xs font-black text-slate-400 uppercase tracking-[0.2em]">추천 대상</span>
                                </div>
                                <div className="p-3 md:p-5 lg:p-6 bg-slate-50/50 rounded-xl md:rounded-[1.5rem] lg:rounded-[2rem] border border-slate-100 flex-1 flex items-center shadow-inner min-h-[60px] md:min-h-[100px]">
                                   <p className="text-slate-800 font-black text-[10px] md:text-lg lg:text-xl leading-relaxed break-keep">
                                       <Markdown
                                          components={{
                                             a: ({ node, ...props }) => {
                                                const href = props.href || '';
                                                if (href.startsWith('book://')) {
                                                   const bookTitle = decodeURIComponent(href.replace('book://', ''));
                                                   const pageIndex = pages.findIndex(p => p.title.includes(bookTitle) || bookTitle.includes(p.title));
                                                   if (pageIndex !== -1) {
                                                      return (
                                                         <button
                                                            onClick={() => {
                                                               setCurrentPage(pageIndex);
                                                               setActiveModal('info');
                                                            }}
                                                            className="text-red-600 hover:underline font-black"
                                                         >
                                                            {props.children}
                                                         </button>
                                                      );
                                                   }
                                                }
                                                return <a {...props} className="text-red-400 underline" />;
                                             }
                                          }}
                                       >
                                          {(pages[currentPage].details?.recommendationTarget || '상세 학습 추천 정보를 확인해 보세요.').replace(/\[\[(.*?)\]\]/g, '[$1](book://$1)')}
                                       </Markdown>
                                   </p>
                                </div>
                             </div>
                          </section>
                          <section className="p-4 md:p-6 lg:p-8 bg-white rounded-2xl md:rounded-[2rem] lg:rounded-[2.5rem] border border-slate-100 shadow-xl shadow-slate-200/50 flex flex-col h-full hover:shadow-2xl transition-shadow duration-500">
                            <div className="space-y-3 flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <div className="p-1.5 md:p-2 bg-slate-50 rounded-lg shadow-sm">
                                   <Zap size={14} className="text-red-500 md:w-4 md:h-4" />
                                </div>
                                <span className="text-[7px] md:text-[10px] lg:text-xs font-black text-slate-400 uppercase tracking-[0.2em]">교재 난이도 분석</span>
                              </div>
                              <div className="relative py-2 md:py-6 px-1 flex-1 flex flex-col justify-center">
                                {(() => {
                                  const difficultyVal = pages[currentPage].details?.levelStats?.vocabulary || 50;
                                  return (
                                    <div className="flex flex-col">
                                      <div className="relative w-full h-3 md:h-6 flex items-center">
                                        <div className="absolute inset-0 flex rounded-full overflow-hidden border border-slate-200 shadow-inner bg-white/60">
                                          {[...Array(5)].map((_, i) => (
                                            <div key={i} className="flex-1 border-r last:border-r-0 border-slate-200/50" />
                                          ))}
                                        </div>
                                        <div className="absolute inset-y-0 left-0 bg-gradient-to-r from-red-400 to-[#E83827] rounded-full transition-all duration-1000 ease-out" style={{ width: `${difficultyVal}%` }} />
                                        <div className="absolute transition-all duration-1000 ease-out flex flex-col items-center" style={{ left: `${difficultyVal}%`, transform: 'translateX(-50%)' }}>
                                           <div className="w-0 h-0 border-l-[3px] md:border-l-[6px] border-l-transparent border-r-[3px] md:border-r-[6px] border-r-transparent border-t-[5px] md:border-t-[10px] border-t-slate-800 mb-[-5px] md:mb-[-10px] z-10" />
                                           <span className="mt-3 md:mt-6 font-black text-white text-[7px] md:text-xs lg:text-sm bg-slate-900 px-2 py-1 md:px-4 md:py-1.5 rounded-lg md:rounded-xl shadow-2xl whitespace-nowrap">
                                              LV: {getDifficultyLabel(difficultyVal)}
                                           </span>
                                        </div>
                                      </div>
                                      <div className="flex justify-between mt-4 md:mt-8 px-1">
                                        {['하', '중하', '중', '중상', '상'].map((label) => (
                                          <span key={label} className="text-[5px] md:text-[10px] lg:text-xs font-black text-slate-300 uppercase tracking-widest">{label}</span>
                                        ))}
                                      </div>
                                    </div>
                                  );
                                })()}
                              </div>
                            </div>
                          </section>
                       </div>

                       <div className="grid grid-cols-1 xl:grid-cols-2 gap-4 md:gap-6">
                          {pages[currentPage].details?.subBooks && pages[currentPage].details!.subBooks!.length > 0 && (
                            <section className="p-4 md:p-6 lg:p-8 bg-white rounded-2xl md:rounded-[2rem] lg:rounded-[2.5rem] border border-slate-100 shadow-xl shadow-slate-200/50 overflow-hidden hover:shadow-2xl transition-shadow duration-500">
                               <h4 className="text-[9px] md:text-lg lg:text-xl font-black text-slate-900 mb-4 md:mb-6 px-1 tracking-tighter flex items-center gap-2 uppercase">
                                  <Layers size={16} className="text-red-500 md:w-5 md:h-5" /> 시리즈 전체 라인업
                               </h4>
                               <div className="overflow-x-auto -mx-1 pr-1 no-scrollbar">
                                  <table className="w-full text-left border-collapse min-w-[300px] md:min-w-[450px]">
                                     <thead>
                                        <tr className="bg-slate-50 border-b border-slate-200">
                                           <th className="px-2 md:px-4 py-2 md:py-3 text-[7px] md:text-[10px] lg:text-xs font-black text-slate-400 uppercase tracking-widest">단계</th>
                                           <th className="px-2 md:px-4 py-2 md:py-3 text-[7px] md:text-[10px] lg:text-xs font-black text-slate-400 uppercase tracking-widest">교재명</th>
                                           <th className="px-2 md:px-4 py-2 md:py-3 text-[7px] md:text-[10px] lg:text-xs font-black text-slate-400 uppercase tracking-widest text-center">대상</th>
                                           <th className="px-2 md:px-4 py-2 md:py-3 text-[7px] md:text-[10px] lg:text-xs font-black text-slate-400 uppercase tracking-widest text-right">정가</th>
                                        </tr>
                                     </thead>
                                     <tbody className="divide-y divide-slate-100">
                                        {pages[currentPage].details!.subBooks!.map((sub, i) => (
                                           <tr key={i} className="cursor-default bg-white hover:bg-slate-50/50 transition-colors">
                                              <td className="px-2 md:px-4 py-3 md:py-5 whitespace-nowrap">
                                                 <span className="px-1.5 py-0.5 md:px-3 md:py-1.5 bg-slate-900 text-white text-[6px] md:text-[10px] font-black rounded-lg uppercase tracking-tighter">
                                                    {sub.step || '-'}
                                                 </span>
                                              </td>
                                              <td className="px-2 md:px-4 py-3 md:py-5">
                                                 <span className="font-black text-[9px] md:text-base lg:text-lg text-slate-800 leading-tight block">{sub.title}</span>
                                              </td>
                                              <td className="px-2 md:px-4 py-3 md:py-5 text-center">
                                                 <span className="font-bold text-slate-600 text-[8px] md:text-xs lg:text-sm">{sub.target || '-'}</span>
                                              </td>
                                              <td className="px-2 md:px-4 py-3 md:py-5 text-right">
                                                 <span className="font-black text-red-600 text-[8px] md:text-xs lg:text-sm">{sub.price || '-'}</span>
                                              </td>
                                           </tr>
                                        ))}
                                     </tbody>
                                  </table>
                               </div>
                            </section>
                          )}

                          {pages[currentPage].details?.nextRecommendations && pages[currentPage].details!.nextRecommendations!.length > 0 && (
                            <section className="p-4 md:p-6 lg:p-8 bg-white rounded-2xl md:rounded-[2rem] lg:rounded-[2.5rem] border border-slate-100 shadow-xl shadow-slate-200/50 overflow-hidden hover:shadow-2xl transition-shadow duration-500">
                               <h4 className="text-[9px] md:text-lg lg:text-xl font-black text-slate-900 mb-4 md:mb-6 px-1 tracking-tighter flex items-center gap-2 uppercase">
                                  <Trophy size={16} className="text-yellow-500 md:w-5 md:h-5" /> 후속 교재 추천
                               </h4>
                               <div className="overflow-x-auto -mx-1 pr-1 no-scrollbar">
                                  <table className="w-full text-left border-collapse min-w-[300px] md:min-w-[500px]">
                                     <thead>
                                        <tr className="bg-slate-50 border-b border-slate-200">
                                           <th className="px-2 md:px-4 py-2 md:py-3 text-[7px] md:text-[10px] lg:text-xs font-black text-slate-400 uppercase tracking-widest w-[100px] md:w-[160px]">추천 카테고리</th>
                                           <th className="px-2 md:px-4 py-2 md:py-3 text-[7px] md:text-[10px] lg:text-xs font-black text-slate-400 uppercase tracking-widest">추천 교재 리스트</th>
                                        </tr>
                                     </thead>
                                     <tbody className="divide-y divide-slate-100">
                                        {pages[currentPage].details!.nextRecommendations!.map((rec, i) => (
                                           <tr key={i} className="cursor-default bg-white hover:bg-slate-50/50 transition-colors">
                                              <td className="px-2 md:px-4 py-4 md:py-6 whitespace-nowrap">
                                                 <span className="px-1.5 py-1 md:px-4 md:py-2 bg-[#E83827] text-white text-[7px] md:text-[10px] lg:text-xs font-black rounded-xl uppercase tracking-tighter shadow-lg shadow-red-100 block text-center">
                                                    {rec.category}
                                                 </span>
                                              </td>
                                              <td className="px-2 md:px-4 py-4 md:py-6">
                                                 <div className="flex flex-wrap gap-x-2 gap-y-1">
                                                    {rec.books.split(',').map((book, bi) => {
                                                       const trimmedBook = book.trim();
                                                       const targetIdx = pages.findIndex(p => p.title.includes(trimmedBook) || trimmedBook.includes(p.title));
                                                       if (targetIdx !== -1) {
                                                          return (
                                                             <button 
                                                                key={bi}
                                                                onClick={() => {
                                                                   setCurrentPage(targetIdx);
                                                                   setActiveModal('info');
                                                                }}
                                                                className="font-black text-red-600 hover:text-red-700 hover:underline text-[9px] md:text-base lg:text-lg leading-relaxed text-left transition-colors"
                                                             >
                                                                {trimmedBook}{bi < rec.books.split(',').length - 1 ? ',' : ''}
                                                             </button>
                                                          );
                                                       }
                                                       return (
                                                          <span key={bi} className="font-bold text-slate-700 text-[9px] md:text-base lg:text-lg leading-relaxed">
                                                             {trimmedBook}{bi < rec.books.split(',').length - 1 ? ',' : ''}
                                                          </span>
                                                       );
                                                    })}
                                                 </div>
                                              </td>
                                           </tr>
                                        ))}
                                     </tbody>
                                  </table>
                               </div>
                            </section>
                          )}
                       </div>
                    </div>
                 </div>
              ) : activeModal === 'ai-consult' ? (
                    <div className="h-full bg-slate-50 rounded-xl md:rounded-[4rem] flex flex-col overflow-hidden">
                      <div className="flex-1 overflow-y-auto p-6 md:p-12 lg:p-16 no-scrollbar">
                        <div className="max-w-4xl mx-auto">
                           <section className="p-6 md:p-10 lg:p-12 bg-slate-900 rounded-[2.5rem] md:rounded-[3.5rem] lg:rounded-[4rem] text-white shadow-2xl relative overflow-hidden group">
                              <div className="absolute top-0 right-0 w-64 h-64 bg-red-600/20 blur-[100px] -mr-32 -mt-32" />
                              <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-600/10 blur-[100px] -ml-32 -mb-32" />
                              
                              <div className="relative z-10 space-y-6 md:space-y-8">
                                 <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                                    <div className="space-y-2">
                                       <div className="inline-flex items-center gap-2 px-3 py-1 bg-red-600 rounded-full text-[8px] md:text-[10px] font-black uppercase tracking-widest">AI Expert</div>
                                       <h4 className="text-[clamp(1.5rem,5vw,3rem)] md:text-3xl lg:text-4xl font-black tracking-tighter leading-tight">AI 1:1 맞춤 교재 상담</h4>
                                       <p className="text-slate-400 font-bold text-[clamp(0.875rem,3vw,1.25rem)] md:text-lg">학생의 수준과 목표를 입력하면 최적의 학습 로드맵을 제안합니다.</p>
                                    </div>
                                 </div>

                                 <form onSubmit={handleAiConsult} className="relative">
                                    <input 
                                       type="text" 
                                       value={aiQuery}
                                       onChange={(e) => setAiQuery(e.target.value)}
                                       placeholder="예: 예비 중1 학생인데 문법 기초가 부족해요. 어떤 교재가 좋을까요?" 
                                       className="w-full p-4 md:p-6 lg:p-8 bg-white/5 border-2 border-white/10 rounded-2xl md:rounded-[2rem] lg:rounded-[2.5rem] text-white placeholder:text-slate-500 font-bold text-[clamp(0.75rem,3vw,1.25rem)] outline-none focus:border-red-500 focus:bg-white/10 transition-all pr-20 md:pr-32"
                                    />
                                    <button 
                                       type="submit"
                                       disabled={isAiLoading}
                                       className="absolute right-2 top-2 bottom-2 md:right-4 md:top-4 md:bottom-4 px-3 md:px-8 bg-red-600 hover:bg-red-500 text-white rounded-xl md:rounded-3xl font-black text-[10px] md:text-lg transition-all flex items-center gap-2 shadow-xl shadow-red-900/20 disabled:opacity-50"
                                    >
                                       {isAiLoading ? <RefreshCw className="animate-spin" size={14} /> : <Zap size={14} />}
                                       <span className="hidden md:inline">분석 시작</span>
                                       <span className="md:hidden">시작</span>
                                    </button>
                                 </form>
                                 {aiResponse && (
                                    <div className="p-6 md:p-10 lg:p-12 bg-white/5 rounded-[2rem] md:rounded-[3rem] border border-white/10 animate-in fade-in slide-in-from-top-4 duration-500">
                                       <div className="flex items-center gap-3 mb-6 md:mb-8">
                                          <div className="w-8 h-8 md:w-12 md:h-12 bg-red-600 rounded-full flex items-center justify-center font-black text-[clamp(1rem,4vw,1.5rem)] md:text-xl">N</div>
                                          <span className="font-black text-[clamp(1rem,4.5vw,1.5rem)] md:text-xl tracking-tight">NE능률 AI 수석 상담원</span>
                                       </div>
                                       <div className="markdown-body text-slate-200 text-[clamp(0.875rem,3.5vw,1.1rem)] md:text-base lg:text-lg leading-relaxed space-y-6 font-medium">
                                          <Markdown
                                             components={{
                                                h3: ({ node, ...props }) => (
                                                   <h3 className="flex items-center gap-2 text-red-500 font-black text-lg md:text-xl mt-8 mb-4 border-l-4 border-red-600 pl-3 bg-white/5 py-2 rounded-r-lg">
                                                      {props.children}
                                                   </h3>
                                                ),
                                                p: ({ node, ...props }) => (
                                                   <p className="mb-4 last:mb-0 text-slate-300 leading-relaxed">
                                                      {props.children}
                                                   </p>
                                                ),
                                                strong: ({ node, ...props }) => (
                                                   <strong className="text-white font-black bg-red-600/20 px-1 rounded">
                                                      {props.children}
                                                   </strong>
                                                ),
                                                a: ({ node, ...props }) => {
                                                   const href = props.href || '';
                                                   if (href.startsWith('book://')) {
                                                      const bookTitle = decodeURIComponent(href.replace('book://', ''));
                                                      const pageIndex = pages.findIndex(p => p.title.includes(bookTitle) || bookTitle.includes(p.title));
                                                      if (pageIndex !== -1) {
                                                         return (
                                                            <button
                                                               onClick={() => {
                                                                  setCurrentPage(pageIndex);
                                                                  setActiveModal('info');
                                                               }}
                                                               className="px-3 py-1 bg-white text-red-600 font-black rounded-full hover:bg-red-50 transition-all inline-flex items-center gap-1.5 mx-1 shadow-lg border border-red-100 transform hover:scale-105 active:scale-95"
                                                            >
                                                               <BookIcon size={14} />
                                                               {props.children}
                                                         </button>
                                                         );
                                                      }
                                                   }
                                                   return <a {...props} className="text-red-400 underline" />;
                                                }
                                             }}
                                          >
                                             {aiResponse.replace(/\[\[(.*?)\]\]/g, '[$1](book://$1)')}
                                          </Markdown>
                                       </div>
                                    </div>
                                 )}
                                       
                                       {aiSources.length > 0 && (
                                          <div className="mt-8 md:mt-12 pt-6 md:pt-8 border-t border-white/10">
                                             <p className="text-[10px] md:text-xs font-black text-slate-500 uppercase tracking-widest mb-4">참고 자료 및 출처</p>
                                             <div className="flex flex-wrap gap-2 md:gap-3">
                                                {aiSources.map((source, idx) => (
                                                   <a 
                                                      key={idx} 
                                                      href={source.web?.uri} 
                                                      target="_blank" 
                                                      rel="noreferrer"
                                                      className="flex items-center gap-2 px-3 py-1.5 md:px-4 md:py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-full text-[9px] md:text-xs font-bold text-slate-400 transition-all"
                                                   >
                                                      <ExternalLink size={12} />
                                                      {source.web?.title || '관련 정보'}
                                                   </a>
                                                ))}
                                             </div>
                                          </div>
                                       )}
                                    </div>
                              </section>
                        </div>
                      </div>
                    </div>
                  ) : activeModal === 'data-manage' ? (
                    <div className="flex-1 flex flex-col justify-center bg-white rounded-xl md:rounded-[4rem] p-4 md:p-6 overflow-hidden">
                      {!isAuthorized ? (
                        <div className="max-w-md mx-auto space-y-4 md:space-y-6 flex flex-col items-center text-center">
                           <div className="w-10 h-10 md:w-16 md:h-16 bg-slate-50 rounded-full flex items-center justify-center text-slate-300"><Lock size={20} /></div>
                           <h4 className="text-sm md:text-xl font-black text-slate-900">관리자 인증</h4>
                           <form onSubmit={handleAdminAuth} className="w-full space-y-3 px-4">
                              <input type="password" value={adminPassword} onChange={(e) => setAdminPassword(e.target.value)} placeholder="비밀번호" className={`w-full p-2.5 md:p-4 bg-slate-50 border-2 rounded-lg md:rounded-2xl font-black text-center text-sm md:text-base outline-none transition-all ${authError ? 'border-red-200 bg-red-50' : 'border-slate-100 focus:border-slate-900'}`} autoFocus />
                              <button type="submit" className="w-full py-2.5 md:py-4 bg-slate-900 text-white rounded-lg md:rounded-2xl font-black shadow-xl hover:bg-black transition-all">인증</button>
                           </form>
                        </div>
                      ) : (
                        <div className="max-w-2xl mx-auto space-y-4 md:space-y-6 px-4 w-full">
                          <div className="text-center space-y-2 md:space-y-3">
                              <div className="w-12 h-12 md:w-16 md:h-16 bg-red-50 text-red-600 rounded-full flex items-center justify-center mx-auto mb-2 md:mb-4 shadow-xl shadow-red-100 transition-transform hover:scale-105 duration-500"><Upload size={20} /></div>
                              <h4 className="text-base md:text-2xl font-black text-slate-900 tracking-tighter">데이터 동기화</h4>
                              {lastSyncTime && (
                                <div className="inline-flex items-center gap-2 px-3 py-1 bg-green-50 text-green-600 rounded-full border border-green-100 animate-in fade-in zoom-in duration-700">
                                   <Check size={12} className="animate-pulse" />
                                   <span className="text-[9px] md:text-[10px] font-black uppercase tracking-tighter">동기화 완료</span>
                                </div>
                              )}
                          </div>
                          
                          <div className="bg-slate-50/50 p-4 md:p-6 rounded-[1.5rem] md:rounded-[2rem] border border-slate-100 flex flex-col items-center text-center gap-2">
                             <div className="flex items-center gap-2 text-slate-400 mb-1">
                               <Clock size={12} />
                               <span className="text-[9px] md:text-[10px] font-black uppercase tracking-widest">Last Sync Time</span>
                             </div>
                             <p className="text-slate-800 font-black text-xs md:text-base italic break-all">
                               {lastSyncTime ? lastSyncTime : '기록된 데이터가 없습니다.'}
                             </p>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 md:gap-4">
                              <button onClick={() => fileInputRef.current?.click()} disabled={isUploading} className="p-4 md:p-6 bg-slate-900 text-white rounded-xl md:rounded-[2rem] flex flex-col items-center justify-center gap-2 md:gap-3 hover:bg-black transition-all shadow-xl active:scale-95">
                                {isUploading ? <RefreshCw className="animate-spin" size={20} /> : <FileText size={20} />}
                                <span className="font-black text-xs md:text-base">파일 업로드</span>
                                <input type="file" ref={fileInputRef} onChange={handleFileUpload} accept=".xlsx, .xls, .csv" className="hidden" />
                              </button>
                              <button onClick={resetData} className="p-4 md:p-6 bg-white border-2 border-slate-100 text-slate-400 rounded-xl md:rounded-[2rem] flex flex-col items-center justify-center gap-2 md:gap-3 hover:bg-red-50 hover:text-red-600 hover:border-red-100 transition-all active:scale-95">
                                <RotateCcw size={20} />
                                <span className="font-black text-xs md:text-base">초기화</span>
                              </button>
                          </div>
                        </div>
                      )}
                    </div>
                  ) : null}
               </div>

               <div className="p-4 md:p-8 border-t bg-slate-50/50 flex justify-center rounded-b-[1rem] md:rounded-b-[4rem] shrink-0">
                  <button onClick={() => setActiveModal(null)} className="px-8 py-3 md:px-16 md:py-5 bg-white border border-slate-200 text-slate-500 rounded-lg md:rounded-2xl font-black text-[9px] md:text-xs uppercase tracking-[0.2em] md:tracking-[0.3em] hover:bg-slate-100 shadow-sm transition-all active:scale-95">CLOSE</button>
               </div>
            </div>
         </div>
      )}

      {isMenuOpen && (
        <>
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-md z-40 animate-in fade-in duration-300" onClick={() => setIsMenuOpen(false)} />
          <div className="absolute top-0 right-0 h-full w-full max-sm:max-w-full sm:max-w-md bg-white z-50 shadow-2xl animate-in slide-in-from-right duration-500 ease-out flex flex-col">
            <div className="p-6 md:p-10 border-b flex items-center justify-between bg-slate-50/50">
              <h3 className="font-black text-2xl md:text-3xl text-slate-900 tracking-tighter">INDEX</h3>
              <button onClick={() => setIsMenuOpen(false)} className="p-2 md:p-3 hover:bg-slate-100 rounded-xl md:rounded-2xl transition-colors"><X size={24} className="md:w-8 md:h-8"/></button>
            </div>
            <div className="flex-1 overflow-y-auto px-4 md:px-6 py-6 space-y-2 md:space-y-3 no-scrollbar">
              {chapters.map((chap, i) => (
                <button key={i} onClick={() => { setCurrentPage(chap.index); setIsMenuOpen(false); }} className={`w-full text-left p-4 md:p-6 rounded-xl md:rounded-[2rem] transition-all flex items-center justify-between group ${currentPage === chap.index ? 'bg-slate-900 text-white shadow-xl scale-[1.01]' : 'hover:bg-slate-50 border border-transparent hover:border-slate-100'}`}>
                  <div className="flex items-center gap-3 md:gap-5">
                    <span className={`text-[10px] md:text-[12px] font-black w-6 h-6 md:w-8 md:h-8 rounded-full flex items-center justify-center ${currentPage === chap.index ? 'bg-red-600' : 'bg-slate-100 text-slate-400'}`}>{i + 1}</span>
                    <span className="font-black tracking-tight text-sm md:text-lg truncate max-w-[150px] md:max-w-[220px]">{chap.name}</span>
                  </div>
                  <ChevronRight size={16} className={currentPage === chap.index ? 'text-red-500' : 'text-slate-200 md:w-[18px] md:h-[18px]'} />
                </button>
              ))}
            </div>
            <div className="p-6 md:p-10 border-t bg-slate-50/50">
               <button onClick={() => { setActiveModal('data-manage'); setIsMenuOpen(false); setIsAuthorized(false); }} className="w-full py-4 md:py-5 bg-white border-2 border-slate-100 rounded-xl md:rounded-2xl flex items-center justify-center gap-2 md:gap-3 text-[10px] md:text-[11px] font-black text-slate-400 hover:text-slate-900 hover:border-slate-300 transition-all active:scale-95">
                  <Database size={14} /> MANAGE CUSTOM DATA
               </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default App;
