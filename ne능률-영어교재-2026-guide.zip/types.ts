
export type PageType = 'front' | 'body' | 'back';

export interface LevelStats {
  vocabulary: number; // 1-100
  grammar: number;    // 1-100
  reading: number;    // 1-100
  overallNelt: number; // 1-9 (NEL -> NELT)
}

export interface RoadmapItem {
  prev?: string;
  next?: string;
  currentLabel: string;
}

export interface NextRecommendation {
  category: string;
  books: string;
}

export interface SubBook {
  title: string;
  step: string;
  target: string;
  pages: string;
  price: string;
}

export interface MultimediaResource {
  id: number;
  label: string;
  type: 'audio' | 'doc' | 'test' | 'video' | 'link';
  url: string;
  desc: string;
}

export interface PageDetails {
  price: string;
  target: string;
  nelt: string; 
  features: string[];
  recommendation?: string;
  recommendationTarget?: string; // 추천 대상 상세 문구 (예: 중학 문법을 체계적으로...)
  levelStats?: LevelStats;
  roadmap?: RoadmapItem;
  nextRecommendations?: NextRecommendation[]; 
  subBooks?: SubBook[]; 
  resources?: MultimediaResource[]; 
}

export interface Page {
  type: PageType;
  title: string;
  content: string;
  image?: string; 
  gallery?: string[]; 
  bg?: string;
  text?: string;
  pageNum?: number;
  details?: PageDetails;
}

export interface Chapter {
  name: string;
  index: number;
}
